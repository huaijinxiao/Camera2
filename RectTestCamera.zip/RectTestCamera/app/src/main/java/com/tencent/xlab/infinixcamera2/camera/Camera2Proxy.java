package com.tencent.xlab.infinixcamera2.camera;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.MeteringRectangle;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.util.Range;
import android.util.Size;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.widget.Toast;

import com.tencent.xlab.infinixcamera2.activity.GLSurfaceCamera2Activity;
import com.tencent.xlab.infinixcamera2.view.Camera2GLSurfaceView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class Camera2Proxy {

    private static final String TAG = "Camera2Proxy";
    private Activity mActivity;


    private int mCameraId = CameraCharacteristics.LENS_FACING_FRONT; // 要打开的摄像头ID
    //    private int mCameraId = CameraCharacteristics.LENS_FACING_EXTERNAL; // 要打开的摄像头ID
    private Size mPreviewSize; // 预览大小
    private CameraManager mCameraManager; // 相机管理者
    private CameraCharacteristics mCameraCharacteristics; // 相机属性
    private CameraDevice mCameraDevice; // 相机对象
    private CameraCaptureSession mCaptureSession;
    private CaptureRequest.Builder mPreviewRequestBuilder; // 相机预览请求的构造器
    private CaptureRequest mPreviewRequest;
    private Handler mBackgroundHandler;
    private HandlerThread mBackgroundThread;
    private ImageReader mImageReader;
    private ImageReader mImageReaderRaw;
    private Surface mPreviewSurface;
    private SurfaceTexture mPreviewSurfaceTexture;
    private OrientationEventListener mOrientationEventListener;


    private int mDisplayRotate = 0;
    private int mDeviceOrientation = 0; // 设备方向，由相机传感器获取
    private int mZoom = 1; // 缩放

    private Range<Integer> isoRange;
    private Range<Long> expTimeRange;
    private int mIso;
    private long mExpTime;
    public long timer;
    public static  String values="";
    public  static  long exp;
    public  static  int iso;


    public static BlockingQueue<CaptureResult> captureRequests = new LinkedBlockingDeque<>();

    /**
     * 打开摄像头的回调
     */
    private CameraDevice.StateCallback mStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            Log.d(TAG, "onOpened");
            mCameraDevice = camera;
            initPreviewRequest();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            Log.d(TAG, "onDisconnected");
            releaseCamera();
        }

        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            Log.e(TAG, "Camera Open failed, error: " + error);
            releaseCamera();
        }
    };

    @TargetApi(Build.VERSION_CODES.M)
    public Camera2Proxy(Activity activity) {
        mActivity = activity;
        mCameraManager = (CameraManager) mActivity.getSystemService(Context.CAMERA_SERVICE);
        mOrientationEventListener = new OrientationEventListener(mActivity) {
            @Override
            public void onOrientationChanged(int orientation) {
                mDeviceOrientation = orientation;
            }
        };
    }

    @SuppressLint("MissingPermission")
    public void openCamera(int width, int height) {
        Log.v(TAG, "openCamera");
        startBackgroundThread(); // 对应 releaseCamera() 方法中的 stopBackgroundThread()
        mOrientationEventListener.enable();
        try {
            mCameraCharacteristics = mCameraManager.getCameraCharacteristics(Integer.toString(mCameraId));
            isoRange = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            expTimeRange = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            if (isoRange != null && expTimeRange != null) {
                mIso = isoRange.getLower();
                mExpTime = expTimeRange.getLower();
            }
            StreamConfigurationMap map = mCameraCharacteristics.get(CameraCharacteristics
                    .SCALER_STREAM_CONFIGURATION_MAP);
            // 拍照大小，选择能支持的一个最大的图片大小
//            Size largest = Collections.max(Arrays.asList(map.getOutputSizes(ImageFormat.JPEG)), new
//                    CompareSizesByArea());
            Size largest = Collections.max(Arrays.asList(map.getOutputSizes(ImageFormat.YUV_420_888)), new
                    CompareSizesByArea());
            Log.d(TAG, "picture size: " + largest.getWidth() + "*" + largest.getHeight());
//            mImageReader = ImageReader.newInstance(largest.getWidth(), largest.getHeight(), ImageFormat.JPEG, 2);
//            mImageReader = ImageReader.newInstance(largest.getWidth(), largest.getHeight(), ImageFormat.YUV_420_888, 4);
            mImageReader = ImageReader.newInstance(largest.getWidth(), largest.getHeight(), ImageFormat.YUV_420_888, 2);
            mImageReaderRaw = ImageReader.newInstance(largest.getWidth(), largest.getHeight(), ImageFormat.RAW_SENSOR, 2);
            // 预览大小，根据上面选择的拍照图片的长宽比，选择一个和控件长宽差不多的大小
//            mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class), width, height, largest);
            mPreviewSize = map.getOutputSizes(SurfaceTexture.class)[0];
            Log.d(TAG, "preview size: " + mPreviewSize.getWidth() + "*" + mPreviewSize.getHeight());
            // 打开摄像头
            mCameraManager.openCamera(Integer.toString(mCameraId), mStateCallback, mBackgroundHandler);
            Log.d(TAG, "Camera id" + mCameraId);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void releaseCamera() {
        Log.v(TAG, "releaseCamera");
        if (null != mCaptureSession) {
            mCaptureSession.close();
            mCaptureSession = null;
        }
        if (mCameraDevice != null) {
            mCameraDevice.close();
            mCameraDevice = null;
        }
        if (mImageReader != null) {
            mImageReader.close();
            mImageReader = null;
        }
        if (mImageReaderRaw != null) {
            mImageReaderRaw.close();
            mImageReaderRaw = null;
        }
        mOrientationEventListener.disable();
        stopBackgroundThread(); // 对应 openCamera() 方法中的 startBackgroundThread()
    }

    public void setImageAvailableListener(ImageReader.OnImageAvailableListener onImageAvailableListener) {
        if (mImageReader == null) {
            Log.w(TAG, "setImageAvailableListener: mImageReader is null");
            return;
        }
        mImageReader.setOnImageAvailableListener(onImageAvailableListener, null);

    }

    public void setPreviewSurface(SurfaceHolder holder) {
        mPreviewSurface = holder.getSurface();
    }

    public void setPreviewSurface(SurfaceTexture surfaceTexture) {
        mPreviewSurfaceTexture = surfaceTexture;
    }

    private void initPreviewRequest() {
        try {
            mPreviewRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            if (mPreviewSurfaceTexture != null && mPreviewSurface == null) { // use texture view
                mPreviewSurfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
                mPreviewSurface = new Surface(mPreviewSurfaceTexture);
            }

            mPreviewRequestBuilder.addTarget(mPreviewSurface); // 设置预览输出的 Surface
            mCameraDevice.createCaptureSession(Arrays.asList(mPreviewSurface,
                    mImageReader.getSurface()), new CameraCaptureSession.StateCallback() {

                @Override
                public void onConfigured(@NonNull CameraCaptureSession session) {
                    mCaptureSession = session;
                    // 设置连续自动对焦
                    mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest
                            .CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                    // 设置自动曝光
//                            mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest
//                                    .CONTROL_AE_MODE_ON_AUTO_FLASH);

                    // 设置完后自动开始预览
                    mPreviewRequest = mPreviewRequestBuilder.build();
                    startPreview();
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                    Log.e(TAG, "ConfigureFailed. session: mCaptureSession");
                }
            }, mBackgroundHandler);

        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void startPreview() {
        Log.v(TAG, "startPreview");
        if (mCaptureSession == null || mPreviewRequestBuilder == null) {
            Log.w(TAG, "startPreview: mCaptureSession or mPreviewRequestBuilder is null");
            return;
        }
        try {
            // 开始预览，即一直发送预览的请求
            mCaptureSession.setRepeatingRequest(mPreviewRequest, null, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void stopPreview() {
        Log.v(TAG, "stopPreview");
        if (mCaptureSession == null || mPreviewRequestBuilder == null) {
            Log.w(TAG, "stopPreview: mCaptureSession or mPreviewRequestBuilder is null");
            return;
        }
        try {
            mCaptureSession.stopRepeating();
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void captureImageBurst(int parseInt) {
        CaptureRequest.Builder captureBuilder = null;
        try {
            captureBuilder = mCameraDevice.createCaptureRequest(CameraDevice
                    .TEMPLATE_STILL_CAPTURE);

            captureBuilder.addTarget(mImageReader.getSurface());

            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(mDeviceOrientation));
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
            captureBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, mIso);
            captureBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, mExpTime);
            // 预览如果有放大，拍照的时候也应该保存相同的缩放
            Rect zoomRect = mPreviewRequestBuilder.get(CaptureRequest.SCALER_CROP_REGION);
            if (zoomRect != null) {
                captureBuilder.set(CaptureRequest.SCALER_CROP_REGION, zoomRect);
            }
            ArrayList<CaptureRequest> captureImageRequests = new ArrayList();
            CaptureRequest captureRequest = captureBuilder.build();
            for (int i = 0; i < parseInt; i++) {
                captureImageRequests.add(captureRequest);
            }
            mCaptureSession.captureBurst(captureImageRequests, new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                               @NonNull CaptureRequest request,
                                               @NonNull TotalCaptureResult result) {
//                    try {
//                        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata
//                                .CONTROL_AF_TRIGGER_CANCEL);
//                        mCaptureSession.capture(mPreviewRequestBuilder.build(), null, mBackgroundHandler);
//                    } catch (CameraAccessException e) {
//                        e.printStackTrace();
//                    }
                    super.onCaptureCompleted(session, request, result);
                    try {
                        captureRequests.put(result);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
//                    startPreview();
                }
            }, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

    }

    public void captureStillPicture() {
        try {
            CaptureRequest.Builder captureBuilder = mCameraDevice.createCaptureRequest(CameraDevice
                    .TEMPLATE_STILL_CAPTURE);

            captureBuilder.addTarget(mImageReader.getSurface());

            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(mDeviceOrientation));
            captureBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            //原设计为手动控制iso exp 现改为如上的自动模式
            /*captureBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
            captureBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, mIso);
            captureBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, mExpTime);*/
            // 预览如果有放大，拍照的时候也应该保存相同的缩放
            Rect zoomRect = mPreviewRequestBuilder.get(CaptureRequest.SCALER_CROP_REGION);
            if (zoomRect != null) {
                captureBuilder.set(CaptureRequest.SCALER_CROP_REGION, zoomRect);
            }
            mCaptureSession.stopRepeating();
            mCaptureSession.abortCaptures();
            final long time = System.currentTimeMillis();
            mCaptureSession.capture(captureBuilder.build(), new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                               @NonNull CaptureRequest request,
                                               @NonNull TotalCaptureResult result) {

                    StringBuilder sb=new StringBuilder("");
                    String lightMode = GLSurfaceCamera2Activity.lightmode;
                    sb.append("lightMode:").append(lightMode).append(",");
                    float lux= GLSurfaceCamera2Activity.mlight;
                    sb.append("light:").append(lux).append(",");
                    exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
                    sb.append("exp:").append(exp).append(",");
                    iso = result.get(CaptureResult.SENSOR_SENSITIVITY);
                    sb.append("iso:").append(iso).append(",");
                    float focu_distance = result.get(CaptureResult.LENS_FOCUS_DISTANCE);
                    sb.append("focu_distance:").append(focu_distance).append(",");
                   /* long senor_fd = result.get(CaptureResult.SENSOR_FRAME_DURATION);
                    sb.append("senor_fd:").append(senor_fd);*/
                    //黑电平补偿是锁定在当前值上
                    boolean aBoolean = result.get(CaptureResult.BLACK_LEVEL_LOCK);
                    sb.append("BLACK_LEVEL_LOCK:").append(aBoolean).append(",");
                    //色差校正算法的操作模式
                    int integer = result.get(CaptureResult.COLOR_CORRECTION_ABERRATION_MODE);
                    sb.append("COLOR_CORRECTION_ABERRATION_MODE:").append(integer).append(",");
                    //颜色校正模式
                    int integer1 = result.get(CaptureResult.COLOR_CORRECTION_MODE);
                    sb.append("COLOR_CORRECTION_MODE:").append(integer1).append(",");
                    //CONTROL_AE_ANTIBANDING_MODE	相机自动曝光算法的反冲带补偿所需的设置
                    int integer2 = result.get(CaptureResult.CONTROL_AE_ANTIBANDING_MODE);
                    sb.append("CONTROL_AE_ANTIBANDING_MODE:").append(integer2).append(",");
                    //调整自动曝光(AE)目标图像亮度
                    int integer3 = result.get(CaptureResult.CONTROL_AE_EXPOSURE_COMPENSATION);
                    sb.append("CONTROL_AE_EXPOSURE_COMPENSATION:").append(integer3).append(",");
                    //CONTROL_AE_LOCK	自动曝光(AE)现在是否锁定为其最新计算值
                    boolean aBoolean1 = result.get(CaptureResult.CONTROL_AE_LOCK);
                    sb.append("CONTROL_AE_LOCK:").append(aBoolean1).append(",");

                    //CONTROL_AE_MODE	相机自动曝光程序所需的模式
                    int integer4 = result.get(CaptureResult.CONTROL_AE_MODE);
                    sb.append("CONTROL_AE_MODE:").append(integer4).append(",");

                    //CONTROL_AE_PRECAPTURE_TRIGGER	相机设备在处理此请求时是否触发预捕获测光
                    int integer5 = result.get(CaptureResult.CONTROL_AE_PRECAPTURE_TRIGGER);
                    sb.append("CONTROL_AE_PRECAPTURE_TRIGGER:").append(integer5).append(",");

                    //CONTROL_AF_MODE	自动对焦(AF)当前是否启用，以及设置为何种模式
                    int integer6 = result.get(CaptureResult.CONTROL_AF_MODE);
                    sb.append("CONTROL_AF_MODE:").append(integer6).append(",");

                    //CONTROL_AF_TRIGGER	相机设备是否会为该请求触发自动对焦
                    int integer7 = result.get(CaptureResult.CONTROL_AF_TRIGGER);
                    sb.append("CONTROL_AF_TRIGGER:").append(integer7).append(",");

                    //CONTROL_AWB_LOCK	自动白平衡(AWB)现在是否锁定为其最新计算值
                    boolean aBoolean2 = result.get(CaptureResult.CONTROL_AWB_LOCK);
                    sb.append("CONTROL_AWB_LOCK:").append(aBoolean2).append(",");
                    //CONTROL_AWB_MODE	自动白平衡(AWB)当前是否设置颜色转换字段，以及它的光照目标是什么
                    int integer8 = result.get(CaptureResult.CONTROL_AWB_MODE);
                    sb.append("CONTROL_AWB_MODE:").append(integer8).append(",");

                    //CONTROL_CAPTURE_INTENT	关于该捕捉目的的3A（自动曝光，自动对焦，自动白平衡）信息，帮助相机设备决定最优的3A策略
                    int integer9 = result.get(CaptureResult.CONTROL_CAPTURE_INTENT);
                    sb.append("CONTROL_CAPTURE_INTENT:").append(integer9).append(",");

                    //CONTROL_ENABLE_ZSL	运行相机设备为 android.control.captureIntent == STILL_CAPTURE 的请求开启零延迟（zero-shutter-lag）模式

                    //CONTROL_MODE	整个3A控制程序模式
                    int integer10 = result.get(CaptureResult.CONTROL_MODE);
                    sb.append("CONTROL_MODE:").append(integer10).append(",");

                    //CONTROL_POST_RAW_SENSITIVITY_BOOST	捕获原始传感器数据后应用于输出图像的额外灵敏度提升量
                    /*int integer11 = result.get(CaptureResult.CONTROL_POST_RAW_SENSITIVITY_BOOST);
                    sb.append("     CONTROL_POST_RAW_SENSITIVITY_BOOST: ").append(integer11);*/
                    //CONTROL_SCENE_MODE	当前处于活动状态的场景模式
                    int integer11 = result.get(CaptureResult.CONTROL_SCENE_MODE);
                    sb.append("CONTROL_SCENE_MODE: ").append(integer11).append(",");
                    result.get(CaptureResult.CONTROL_AE_PRECAPTURE_TRIGGER);
                    int flash =GLSurfaceCamera2Activity.flashState;
                    sb.append("Flash_Mode:").append(flash).append(",");
                    values=sb.toString();
                    Log.e(TAG, "onCaptureCompleted:"+values );
                    Log.w(TAG, "onCaptureCompleted, time: " + (System.currentTimeMillis() - time));
                    values=sb.toString();
                    Log.e(TAG, "onCaptureCompleted: "+values );
                    try {
                        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata
                                .CONTROL_AF_TRIGGER_CANCEL);
                        mCaptureSession.capture(mPreviewRequestBuilder.build(), null, mBackgroundHandler);
                    } catch (CameraAccessException e) {
                        e.printStackTrace();
                    }
                    startPreview();
                }
            }, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private int getJpegOrientation(int deviceOrientation) {
        if (deviceOrientation == OrientationEventListener.ORIENTATION_UNKNOWN)
            return 0;
        int sensorOrientation = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        // Round device orientation to a multiple of 90
        deviceOrientation = (deviceOrientation + 45) / 90 * 90;
        // Reverse device orientation for front-facing cameras
        boolean facingFront = mCameraCharacteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics
                .LENS_FACING_FRONT;
        if (facingFront) deviceOrientation = -deviceOrientation;
        // Calculate desired JPEG orientation relative to camera orientation to make
        // the image upright relative to the device orientation
        int jpegOrientation = (sensorOrientation + deviceOrientation + 360) % 360;
        Log.d(TAG, "jpegOrientation: " + jpegOrientation);
        return jpegOrientation;
    }

    public boolean isFrontCamera() {
        return mCameraId == CameraCharacteristics.LENS_FACING_BACK;
    }

    public Size getPreviewSize() {
        return mPreviewSize;
    }

    public void switchCamera(int width, int height) {
        mCameraId ^= 1;
        Log.d(TAG, "switchCamera: mCameraId: " + mCameraId);
        releaseCamera();
        openCamera(width, height);
    }

    /**
     * 设置Camera闪光灯
     *
     * @param flashState 0:开启； 1 ：关闭
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void setFlash(int flashState) {
        if (flashState == 0) {
            openFlash();
        } else {
            closeFlash();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void openFlash() {
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);//设置曝光
        mPreviewRequestBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH);
        mPreviewRequest = mPreviewRequestBuilder.build();
        startPreview();
    }

    private void closeFlash() {
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
        mPreviewRequestBuilder.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_OFF);
        mPreviewRequest = mPreviewRequestBuilder.build();
        startPreview();
    }

    public void setIsoChange(int iso) {
        if (isoRange != null) {
            int max1 = isoRange.getUpper();
            int min1 = isoRange.getLower();
//            if (iso > max1){
//                mIso = max1;
//            }else if (iso < min1){
//                mIso = min1;
//            }else {
//                mIso = iso;
//            }
            mIso = iso;
            mPreviewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
//        //设置每秒30帧
            Range<Integer> fps[] = mCameraCharacteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fps[fps.length - 1]);
            mPreviewRequestBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, mIso);
            mPreviewRequestBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, mExpTime);
            mPreviewRequest = mPreviewRequestBuilder.build();
            startPreview();
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    GLSurfaceCamera2Activity.tv_iso.setText(String.valueOf(mIso));
                    GLSurfaceCamera2Activity.tv_exp.setText(String.valueOf(mExpTime / 1000));
                }
            });
        } else {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    GLSurfaceCamera2Activity.tv_iso.setText("获取不到 SENSOR_INFO_SENSITIVITY_RANGE");
                }
            });
        }
    }

    public void setExpChange(long expTime) {
        if (expTimeRange != null) {
            long max3 = expTimeRange.getUpper();
            long min3 = expTimeRange.getLower();
            if (expTime > max3) {
                mExpTime = max3;
            } else if (expTime < min3) {
                mExpTime = min3;
            } else {
                mExpTime = expTime;
            }
            mPreviewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
            mPreviewRequestBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, mIso);
            mPreviewRequestBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, mExpTime);
            Log.e(TAG, "expTime " + mExpTime + "ISO " + mIso);
            Log.e(TAG, "max3 " + max3 + "min3 " + min3);
            mPreviewRequest = mPreviewRequestBuilder.build();
            startPreview();
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
//                    GLSurfaceCamera2Activity.tv_iso.setText("iso:" + mIso + "\n曝光：" + mExpTime/1000 + "us");
                    GLSurfaceCamera2Activity.tv_iso.setText(String.valueOf(mIso));
                    GLSurfaceCamera2Activity.tv_exp.setText(String.valueOf(mExpTime / 1000));
                }
            });
        } else {
            mActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    GLSurfaceCamera2Activity.tv_iso.setText("获取不到 SENSOR_INFO_EXPOSURE_TIME_RANGE");
                }
            });
        }
    }


    private Size chooseOptimalSize(Size[] sizes, int viewWidth, int viewHeight, Size pictureSize) {
        int totalRotation = getRotation();
        boolean swapRotation = totalRotation == 90 || totalRotation == 270;
        int width = swapRotation ? viewHeight : viewWidth;
        int height = swapRotation ? viewWidth : viewHeight;
        return getSuitableSize(sizes, width, height, pictureSize);
    }

    private int getRotation() {
        int displayRotation = mActivity.getWindowManager().getDefaultDisplay().getRotation();
        switch (displayRotation) {
            case Surface.ROTATION_0:
                displayRotation = 90;
                break;
            case Surface.ROTATION_90:
                displayRotation = 0;
                break;
            case Surface.ROTATION_180:
                displayRotation = 270;
                break;
            case Surface.ROTATION_270:
                displayRotation = 180;
                break;
        }
        int sensorOrientation = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        mDisplayRotate = (displayRotation + sensorOrientation + 270) % 360;
        return mDisplayRotate;
    }

    private Size getSuitableSize(Size[] sizes, int width, int height, Size pictureSize) {
        int minDelta = Integer.MAX_VALUE; // 最小的差值，初始值应该设置大点保证之后的计算中会被重置
        int index = 0; // 最小的差值对应的索引坐标
        float aspectRatio = pictureSize.getHeight() * 1.0f / pictureSize.getWidth();
        Log.d(TAG, "getSuitableSize. aspectRatio: " + aspectRatio);
        for (int i = 0; i < sizes.length; i++) {
            Size size = sizes[i];
            // 先判断比例是否相等
            if (size.getWidth() * aspectRatio == size.getHeight()) {
                int delta = Math.abs(width - size.getWidth());
                if (delta == 0) {
                    return size;
                }
                if (minDelta > delta) {
                    minDelta = delta;
                    index = i;
                }
            }
        }
        return sizes[index];
    }

    public void handleZoom(boolean isZoomIn) {
        if (mCameraDevice == null || mCameraCharacteristics == null || mPreviewRequestBuilder == null) {
            return;
        }
        int maxZoom = mCameraCharacteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM).intValue()
                * 10;
        Log.d(TAG, "handleZoom: maxZoom: " + maxZoom);
        Rect rect = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        if (isZoomIn && mZoom < maxZoom) {
            mZoom++;
        } else if (mZoom > 1) {
            mZoom--;
        }
        Log.d(TAG, "handleZoom: mZoom: " + mZoom);
        int minW = rect.width() / maxZoom;
        int minH = rect.height() / maxZoom;
        int difW = rect.width() - minW;
        int difH = rect.height() - minH;
        int cropW = difW * mZoom / 100;
        int cropH = difH * mZoom / 100;
        cropW -= cropW & 3;
        cropH -= cropH & 3;
        Log.d(TAG, "handleZoom: cropW: " + cropW + ", cropH: " + cropH);
        Rect zoomRect = new Rect(cropW, cropH, rect.width() - cropW, rect.height() - cropH);
        mPreviewRequestBuilder.set(CaptureRequest.SCALER_CROP_REGION, zoomRect);
        mPreviewRequest = mPreviewRequestBuilder.build();
        startPreview(); // 需要重新 start preview 才能生效
    }

    public void focusOnPoint(double x, double y, int width, int height) {
        if (mCameraDevice == null || mPreviewRequestBuilder == null) {
            return;
        }
        // 1. 先取相对于view上面的坐标
        int previewWidth = mPreviewSize.getWidth();
        int previewHeight = mPreviewSize.getHeight();
        if (mDisplayRotate == 90 || mDisplayRotate == 270) {
            previewWidth = mPreviewSize.getHeight();
            previewHeight = mPreviewSize.getWidth();
        }
        // 2. 计算摄像头取出的图像相对于view放大了多少，以及有多少偏移
        double tmp;
        double imgScale;
        double verticalOffset = 0;
        double horizontalOffset = 0;
        if (previewHeight * width > previewWidth * height) {
            imgScale = width * 1.0 / previewWidth;
            verticalOffset = (previewHeight - height / imgScale) / 2;
        } else {
            imgScale = height * 1.0 / previewHeight;
            horizontalOffset = (previewWidth - width / imgScale) / 2;
        }
        // 3. 将点击的坐标转换为图像上的坐标
        x = x / imgScale + horizontalOffset;
        y = y / imgScale + verticalOffset;
        if (90 == mDisplayRotate) {
            tmp = x;
            x = y;
            y = mPreviewSize.getHeight() - tmp;
        } else if (270 == mDisplayRotate) {
            tmp = x;
            x = mPreviewSize.getWidth() - y;
            y = tmp;
        }
        // 4. 计算取到的图像相对于裁剪区域的缩放系数，以及位移
        Rect cropRegion = mPreviewRequestBuilder.get(CaptureRequest.SCALER_CROP_REGION);
        if (cropRegion == null) {
            Log.w(TAG, "can't get crop region");
            cropRegion = mCameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        }
        int cropWidth = cropRegion.width();
        int cropHeight = cropRegion.height();
        if (mPreviewSize.getHeight() * cropWidth > mPreviewSize.getWidth() * cropHeight) {
            imgScale = cropHeight * 1.0 / mPreviewSize.getHeight();
            verticalOffset = 0;
            horizontalOffset = (cropWidth - imgScale * mPreviewSize.getWidth()) / 2;
        } else {
            imgScale = cropWidth * 1.0 / mPreviewSize.getWidth();
            horizontalOffset = 0;
            verticalOffset = (cropHeight - imgScale * mPreviewSize.getHeight()) / 2;
        }
        // 5. 将点击区域相对于图像的坐标，转化为相对于成像区域的坐标
        x = x * imgScale + horizontalOffset + cropRegion.left;
        y = y * imgScale + verticalOffset + cropRegion.top;
        double tapAreaRatio = 0.1;
        Rect rect = new Rect();
        rect.left = clamp((int) (x - tapAreaRatio / 2 * cropRegion.width()), 0, cropRegion.width());
        rect.right = clamp((int) (x + tapAreaRatio / 2 * cropRegion.width()), 0, cropRegion.width());
        rect.top = clamp((int) (y - tapAreaRatio / 2 * cropRegion.height()), 0, cropRegion.height());
        rect.bottom = clamp((int) (y + tapAreaRatio / 2 * cropRegion.height()), 0, cropRegion.height());
        // 6. 设置 AF、AE 的测光区域，即上述得到的 rect
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_REGIONS, new MeteringRectangle[]{new MeteringRectangle
                (rect, 1000)});
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_REGIONS, new MeteringRectangle[]{new MeteringRectangle
                (rect, 1000)});
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO);
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START);
        mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata
                .CONTROL_AE_PRECAPTURE_TRIGGER_START);
        try {
            // 7. 发送上述设置的对焦请求，并监听回调
            mCaptureSession.capture(mPreviewRequestBuilder.build(), mAfCaptureCallback, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private final CameraCaptureSession.CaptureCallback mAfCaptureCallback = new CameraCaptureSession.CaptureCallback() {

        private void process(CaptureResult result) {
            Integer state = result.get(CaptureResult.CONTROL_AF_STATE);
            if (null == state) {
                return;
            }
            Log.d(TAG, "process: CONTROL_AF_STATE: " + state);
            if (state == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED || state == CaptureResult
                    .CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
                Log.d(TAG, "process: start normal preview");
                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL);//撤销对焦
                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest
                        .CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                mPreviewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.FLASH_MODE_OFF);
                startPreview();
            }
        }

        @Override
        public void onCaptureProgressed(@NonNull CameraCaptureSession session,
                                        @NonNull CaptureRequest request,
                                        @NonNull CaptureResult partialResult) {
            process(partialResult);
        }

        @Override
        public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                       @NonNull CaptureRequest request,
                                       @NonNull TotalCaptureResult result) {
            process(result);
        }
    };


    private void startBackgroundThread() {
        if (mBackgroundThread == null || mBackgroundHandler == null) {
            Log.v(TAG, "startBackgroundThread");
            mBackgroundThread = new HandlerThread("CameraBackground");
            mBackgroundThread.start();
            mBackgroundHandler = new Handler(mBackgroundThread.getLooper());
        }
    }

    private void stopBackgroundThread() {
        Log.v(TAG, "stopBackgroundThread");
        mBackgroundThread.quitSafely();
        try {
            mBackgroundThread.join();
            mBackgroundThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private int clamp(int x, int min, int max) {
        if (x > max) return max;
        if (x < min) return min;
        return x;
    }

    public int getIso() {
        return mIso;
    }

    public double getmExpTime() {
        return (double) mExpTime / 1000000;
    }


    /**
     * Compares two {@code Size}s based on their areas.
     */
    static class CompareSizesByArea implements Comparator<Size> {

        @Override
        public int compare(Size lhs, Size rhs) {
            // We cast here to ensure the multiplications won't overflow
            return Long.signum((long) lhs.getWidth() * lhs.getHeight() -
                    (long) rhs.getWidth() * rhs.getHeight());
        }
    }

}
